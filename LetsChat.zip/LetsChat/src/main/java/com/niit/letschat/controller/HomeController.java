package com.niit.letschat.controller;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.letschat.model.User;
import com.niit.letschat.service.Userservice;

@Controller
public class HomeController {
	
	@Autowired
	Userservice userservice;
	
	@RequestMapping("/")
	public ModelAndView home()
	{
		return new ModelAndView("home");
	}
	@RequestMapping("/signUp")
	public ModelAndView signUpdata()
	{
		User user= new User();
		System.out.println("signup method called");
		return new ModelAndView("signUp","user",user);
		
	}
	@RequestMapping("/home")
	public ModelAndView hom()
	{
		System.out.println("I am in home page");
		return new ModelAndView("home");
	}
	@RequestMapping("/logout")
	public ModelAndView logout()
	{
		System.out.println("I am in logout page");
		return new ModelAndView("logout");
	}
	
	
	@RequestMapping("/viewHome")
	public String logouthome()
	{
		return "redirect:/Blog";
	}	
	
	@RequestMapping("/register")
	public String createUser(@Valid@ModelAttribute("user") User user , Model model,HttpServletRequest request,@RequestParam("image") MultipartFile file, BindingResult br) 
	{
		if(br.hasErrors())
		{
			System.out.println("error");
			return "signUp";
		}
		System.out.println("register");
		
		String filename = null;
	    byte[] bytes;
	    	userservice.saveOrUpdate(user);
	    		System.out.println("Data Inserted");
	            
	    		MultipartFile image = user.getImage();
	      // String path = request.getSession().getServletContext().getRealPath("/WEB-INF/resources/images/"+user.getId()+".jpg");
	        Path path=Paths.get("H://PROJECT2//Chatapp//src//main//webapp//WEB-INF//resources//images//"+user.getId());
	    		System.out.println("Path="+path);
	            System.out.println("File name = " + user.getImage().getOriginalFilename());
	          
	            if(image!=null && !image.isEmpty())
	            {
	            	try
	            	{
	            		image.transferTo(new File(path.toString()));
	            		System.out.println("Image saved  in:"+path.toString());
	            	}
	            	catch(Exception e)
	            	{
	            		e.printStackTrace();
	            		System.out.println("Image not saved");
	            	}
	            }
	    	
	     	    
	    return "login";
	}
	    @RequestMapping("/login")
		public String loginMethod()
		{
			return "login";
		}
	    
	    
	    
	    
	    @RequestMapping("/contactus")
		public ModelAndView Contactus()
		{
			System.out.println("I am in contactus");
			return new ModelAndView("contactus");
		}
		

	@ModelAttribute("user")
	public  User returnObject()
	{
		return new User();
	}
	}
	


