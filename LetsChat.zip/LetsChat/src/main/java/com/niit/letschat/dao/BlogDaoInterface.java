package com.niit.letschat.dao;

import java.util.List;

import com.niit.letschat.model.Blog;

public interface BlogDaoInterface {
	public void createNewBlog(Blog blog);
	public List<Blog> getBlogList(String bUserName);
	public Blog getBlogById(int bid);
	public Blog getBlogByName(String bname);
	public void delete(int bid);
	public List<Blog> getBlog();

}
