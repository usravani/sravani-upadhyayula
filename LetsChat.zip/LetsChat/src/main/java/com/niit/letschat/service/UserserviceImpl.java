package com.niit.letschat.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.letschat.dao.UserDaoInterface;
import com.niit.letschat.model.User;


@Service
public class UserserviceImpl implements Userservice{
	
	@Autowired
	UserDaoInterface userdao;
	
	@Transactional
	public void setUserDao(UserDaoInterface userdao)
	{
		this.userdao=userdao;
	}

	@Transactional
	public void saveOrUpdate(User user) {
		userdao.saveOrUpdate(user);
		
	}

	@Transactional
	public User getUserById(int id) {
		
		return userdao.getUserById(id);
	}

	@Transactional
	public List<User> list() {
		
		return userdao.list();
	}

	@Transactional
	public User getUserByname(String username) {
		
		return userdao.getUserByname(username);
	}
	
	/*@Transactional
	public boolean  login(String username , String password)
	{
		return userdao.login(username, password);
	}*/

}
