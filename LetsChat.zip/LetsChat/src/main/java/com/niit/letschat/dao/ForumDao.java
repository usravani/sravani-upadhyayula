package com.niit.letschat.dao;

import java.util.List;

import com.niit.letschat.model.Forum;

public interface ForumDao {
	public void createNewForum(Forum f);
	public List<Forum> getForumList(String UserName);
	public void delete(int fid);
	public List<Forum> getForum();

}
