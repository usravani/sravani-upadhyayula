package com.niit.letschat.service;

import java.util.List;

import com.niit.letschat.model.User;



public interface Userservice {
	public void saveOrUpdate(User user);
	public User getUserById(int id);
	public  List<User> list();
	public User getUserByname(String username);
	

}
