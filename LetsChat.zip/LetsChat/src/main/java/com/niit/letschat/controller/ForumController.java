package com.niit.letschat.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.niit.letschat.model.Forum;
import com.niit.letschat.service.ForumService;

@Controller
public class ForumController {
	@Autowired
	private ForumService forumservice;


	@RequestMapping("/newforum")
	public String createBlog(HttpServletRequest request,Model model)
	{
		String name=request.getParameter("forum");
		model.addAttribute("name",name);
		System.out.println("In Forum Controller");
		return "Forum";
	}
	
	@ModelAttribute("forum")
	public Forum returnObject()
	{
		return new Forum();
	}

	@RequestMapping("/postF")
	public String postblog(@ModelAttribute("forum") Forum forum , Model model) throws IOException
	{
		System.out.println("I am in Forum");
		
		forum.setForumUserName("forum hai");
		forum.setCreationdatetime(new java.util.Date());
		
		forumservice.createNewForum(forum);
		
		return "Forum";
	
	}
	
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/GsonCon1")
	public @ResponseBody String getValues() throws Exception
	{
		List<Forum> flist;
		String result="";
		flist = forumservice.getForum();
		Gson gson = new Gson();
		result = gson.toJson(flist);
		System.out.println("before flist");
		System.out.println(flist);
		return result;
	}
	
	

}
